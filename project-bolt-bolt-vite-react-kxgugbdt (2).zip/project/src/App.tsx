import React, { useState } from 'react'
import {
  Calendar,
  Clock,
  Users,
  User,
  CheckCircle2,
  XCircle,
  Settings,
  Bell,
  Search,
  Filter,
  Calendar as CalendarIcon,
  MessageSquare,
  LogOut
} from 'lucide-react'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedDepartment, setSelectedDepartment] = useState('all')
  const [showNotifications, setShowNotifications] = useState(false)

  const meetings = [
    { 
      id: 1, 
      lecturer: "Dr. Sarah Wilson", 
      subject: "Project Discussion", 
      date: "2025-03-15", 
      time: "10:00 AM", 
      status: "approved",
      department: "Computer Science",
      location: "Room 301",
      duration: "30 minutes",
      notes: "Bring project documentation"
    },
    { 
      id: 2, 
      lecturer: "Prof. James Smith", 
      subject: "Thesis Review", 
      date: "2025-03-16", 
      time: "2:30 PM", 
      status: "pending",
      department: "Engineering",
      location: "Online (Zoom)",
      duration: "45 minutes",
      notes: "Prepare thesis draft"
    },
    { 
      id: 3, 
      lecturer: "Dr. Michael Brown", 
      subject: "Research Consultation", 
      date: "2025-03-17", 
      time: "11:00 AM", 
      status: "pending",
      department: "Physics",
      location: "Lab 204",
      duration: "1 hour",
      notes: "Bring research proposal"
    }
  ]

  const availableSlots = [
    { 
      id: 1, 
      lecturer: "Dr. Sarah Wilson", 
      date: "2025-03-18", 
      time: "9:00 AM",
      department: "Computer Science",
      duration: "30 minutes",
      type: "In-person",
      location: "Room 301"
    },
    { 
      id: 2, 
      lecturer: "Dr. Sarah Wilson", 
      date: "2025-03-18", 
      time: "10:00 AM",
      department: "Computer Science",
      duration: "30 minutes",
      type: "Online",
      location: "Zoom"
    },
    { 
      id: 3, 
      lecturer: "Prof. James Smith", 
      date: "2025-03-19", 
      time: "2:00 PM",
      department: "Engineering",
      duration: "45 minutes",
      type: "In-person",
      location: "Room 405"
    },
    { 
      id: 4, 
      lecturer: "Dr. Michael Brown", 
      date: "2025-03-20", 
      time: "11:30 AM",
      department: "Physics",
      duration: "1 hour",
      type: "In-person",
      location: "Lab 204"
    }
  ]

  const notifications = [
    {
      id: 1,
      type: "approval",
      message: "Your meeting with Dr. Sarah Wilson has been approved",
      time: "2 hours ago"
    },
    {
      id: 2,
      type: "reminder",
      message: "Upcoming meeting with Prof. James Smith tomorrow at 2:30 PM",
      time: "5 hours ago"
    },
    {
      id: 3,
      type: "cancellation",
      message: "Meeting with Dr. Michael Brown has been cancelled",
      time: "1 day ago"
    }
  ]

  const departments = [
    "all",
    "Computer Science",
    "Engineering",
    "Physics",
    "Mathematics",
    "Chemistry"
  ]

  const filteredSlots = availableSlots.filter(slot => 
    (selectedDepartment === 'all' || slot.department === selectedDepartment) &&
    (slot.lecturer.toLowerCase().includes(searchTerm.toLowerCase()) ||
     slot.department.toLowerCase().includes(searchTerm.toLowerCase()))
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-black text-white">
      {/* Header */}
      <header className="bg-blue-950 shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold flex items-center">
              <CalendarIcon className="w-8 h-8 mr-2 text-blue-400" />
              Meeting Scheduler
            </h1>
            <div className="flex items-center space-x-6">
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative p-2 hover:bg-blue-800 rounded-full transition-colors"
                >
                  <Bell className="w-6 h-6" />
                  <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-blue-950 rounded-lg shadow-xl border border-blue-800">
                    <div className="p-4">
                      <h3 className="text-lg font-semibold mb-3">Notifications</h3>
                      <div className="space-y-3">
                        {notifications.map(notification => (
                          <div key={notification.id} className="p-3 bg-blue-900/50 rounded-lg">
                            <p className="text-sm">{notification.message}</p>
                            <p className="text-xs text-blue-400 mt-1">{notification.time}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div className="flex items-center space-x-3">
                <img
                  src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop"
                  alt="Profile"
                  className="w-8 h-8 rounded-full"
                />
                <span>John Doe</span>
              </div>
              <button className="p-2 hover:bg-blue-800 rounded-full transition-colors">
                <Settings className="w-6 h-6" />
              </button>
              <button className="p-2 hover:bg-blue-800 rounded-full transition-colors text-red-400">
                <LogOut className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-blue-900/50 border-b border-blue-800 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-8">
            {['dashboard', 'book', 'meetings', 'calendar', 'messages'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-4 px-3 text-sm font-medium border-b-2 ${
                  activeTab === tab
                    ? 'border-blue-400 text-blue-400'
                    : 'border-transparent hover:border-blue-300 hover:text-blue-300'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-blue-900/30 p-6 rounded-lg border border-blue-800">
                <div className="flex items-center space-x-3 mb-4">
                  <Calendar className="w-6 h-6 text-blue-400" />
                  <h2 className="text-xl font-semibold">Upcoming</h2>
                </div>
                <p className="text-3xl font-bold text-blue-400">3</p>
              </div>
              <div className="bg-blue-900/30 p-6 rounded-lg border border-blue-800">
                <div className="flex items-center space-x-3 mb-4">
                  <Clock className="w-6 h-6 text-blue-400" />
                  <h2 className="text-xl font-semibold">Pending</h2>
                </div>
                <p className="text-3xl font-bold text-blue-400">2</p>
              </div>
              <div className="bg-blue-900/30 p-6 rounded-lg border border-blue-800">
                <div className="flex items-center space-x-3 mb-4">
                  <CheckCircle2 className="w-6 h-6 text-blue-400" />
                  <h2 className="text-xl font-semibold">Completed</h2>
                </div>
                <p className="text-3xl font-bold text-blue-400">5</p>
              </div>
              <div className="bg-blue-900/30 p-6 rounded-lg border border-blue-800">
                <div className="flex items-center space-x-3 mb-4">
                  <Users className="w-6 h-6 text-blue-400" />
                  <h2 className="text-xl font-semibold">Total</h2>
                </div>
                <p className="text-3xl font-bold text-blue-400">8</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-blue-900/30 rounded-lg border border-blue-800">
                <div className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Recent Meetings</h2>
                  <div className="space-y-4">
                    {meetings.slice(0, 3).map((meeting) => (
                      <div key={meeting.id} className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                        <div>
                          <h3 className="font-semibold">{meeting.subject}</h3>
                          <p className="text-sm text-blue-300">{meeting.lecturer}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Clock className="w-4 h-4 text-blue-400" />
                            <p className="text-sm text-blue-300">{meeting.date} at {meeting.time}</p>
                          </div>
                          <div className="flex items-center space-x-2 mt-1">
                            <User className="w-4 h-4 text-blue-400" />
                            <p className="text-sm text-blue-300">{meeting.location}</p>
                          </div>
                        </div>
                        <div className="flex items-center">
                          {meeting.status === 'approved' ? (
                            <span className="flex items-center text-green-400">
                              <CheckCircle2 className="w-5 h-5 mr-1" />
                              Approved
                            </span>
                          ) : (
                            <span className="flex items-center text-yellow-400">
                              <Clock className="w-5 h-5 mr-1" />
                              Pending
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-blue-900/30 rounded-lg border border-blue-800">
                <div className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Quick Book</h2>
                  <div className="space-y-4">
                    {availableSlots.slice(0, 3).map((slot) => (
                      <div key={slot.id} className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                        <div>
                          <h3 className="font-semibold">{slot.lecturer}</h3>
                          <p className="text-sm text-blue-300">{slot.department}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Clock className="w-4 h-4 text-blue-400" />
                            <p className="text-sm text-blue-300">{slot.date} at {slot.time}</p>
                          </div>
                          <div className="flex items-center space-x-2 mt-1">
                            <User className="w-4 h-4 text-blue-400" />
                            <p className="text-sm text-blue-300">{slot.location}</p>
                          </div>
                        </div>
                        <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">
                          Book Now
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'book' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex-1 max-w-md">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Search by lecturer or department..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-blue-900/30 border border-blue-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                  />
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Filter className="text-blue-400 w-5 h-5" />
                <select
                  value={selectedDepartment}
                  onChange={(e) => setSelectedDepartment(e.target.value)}
                  className="bg-blue-900/30 border border-blue-800 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
                >
                  {departments.map(dept => (
                    <option key={dept} value={dept}>
                      {dept === 'all' ? 'All Departments' : dept}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="bg-blue-900/30 rounded-lg border border-blue-800">
              <div className="p-6">
                <h2 className="text-xl font-semibold mb-4">Available Time Slots</h2>
                <div className="space-y-4">
                  {filteredSlots.map((slot) => (
                    <div key={slot.id} className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                      <div>
                        <h3 className="font-semibold">{slot.lecturer}</h3>
                        <p className="text-sm text-blue-300">{slot.department}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Clock className="w-4 h-4 text-blue-400" />
                          <p className="text-sm text-blue-300">
                            {slot.date} at {slot.time} ({slot.duration})
                          </p>
                        </div>
                        <div className="flex items-center space-x-2 mt-1">
                          <User className="w-4 h-4 text-blue-400" />
                          <p className="text-sm text-blue-300">
                            {slot.type} - {slot.location}
                          </p>
                        </div>
                      </div>
                      <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">
                        Book Slot
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'meetings' && (
          <div className="space-y-6">
            <div className="bg-blue-900/30 rounded-lg border border-blue-800">
              <div className="p-6">
                <h2 className="text-xl font-semibold mb-4">All Meetings</h2>
                <div className="space-y-4">
                  {meetings.map((meeting) => (
                    <div key={meeting.id} className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                      <div>
                        <h3 className="font-semibold">{meeting.subject}</h3>
                        <p className="text-sm text-blue-300">{meeting.lecturer}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Clock className="w-4 h-4 text-blue-400" />
                          <p className="text-sm text-blue-300">
                            {meeting.date} at {meeting.time} ({meeting.duration})
                          </p>
                        </div>
                        <div className="flex items-center space-x-2 mt-1">
                          <User className="w-4 h-4 text-blue-400" />
                          <p className="text-sm text-blue-300">{meeting.location}</p>
                        </div>
                        {meeting.notes && (
                          <div className="flex items-center space-x-2 mt-1">
                            <MessageSquare className="w-4 h-4 text-blue-400" />
                            <p className="text-sm text-blue-300">{meeting.notes}</p>
                          </div>
                        )}
                      </div>
                      <div className="flex items-center space-x-4">
                        {meeting.status === 'approved' ? (
                          <span className="flex items-center text-green-400">
                            <CheckCircle2 className="w-5 h-5 mr-1" />
                            Approved
                          </span>
                        ) : (
                          <span className="flex items-center text-yellow-400">
                            <Clock className="w-5 h-5 mr-1" />
                            Pending
                          </span>
                        )}
                        <button className="p-2 text-red-400 hover:text-red-300 rounded-lg transition-colors">
                          <XCircle className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'calendar' && (
          <div className="space-y-6">
            <div className="bg-blue-900/30 rounded-lg border border-blue-800 p-6">
              <h2 className="text-xl font-semibold mb-4">Calendar View</h2>
              <p className="text-blue-300">Calendar implementation coming soon...</p>
            </div>
          </div>
        )}

        {activeTab === 'messages' && (
          <div className="space-y-6">
            <div className="bg-blue-900/30 rounded-lg border border-blue-800 p-6">
              <h2 className="text-xl font-semibold mb-4">Messages</h2>
              <p className="text-blue-300">Messaging system implementation coming soon...</p>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

export default App